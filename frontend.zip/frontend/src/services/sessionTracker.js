/**
 * Session Tracking Utility Service
 * Classifies frontend routes and prepares session feature vectors for ML backend.
 */

export const PAGE_CATEGORIES = {
  ADMINISTRATIVE: ["/cart", "/checkout", "/account", "/orders"],
  INFORMATIONAL: ["/about", "/faq", "/shipping", "/returns", "/contact"],
  PRODUCT_RELATED: ["/", "/products", "/product", "/search", "/categories"],
};

export function classifyPageType(path) {
  if (PAGE_CATEGORIES.ADMINISTRATIVE.some((p) => path.startsWith(p))) {
    return "Administrative";
  }
  if (PAGE_CATEGORIES.INFORMATIONAL.some((p) => path.startsWith(p))) {
    return "Informational";
  }
  return "ProductRelated";
}

export function getCurrentMonthName() {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "June", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const currentMonthIndex = new Date().getMonth();
  const validDatasetMonths = ["Feb", "Mar", "May", "June", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const detected = months[currentMonthIndex];
  return validDatasetMonths.includes(detected) ? detected : "May";
}

export function isWeekendNow() {
  const day = new Date().getDay();
  return day === 0 || day === 6;
}

export function buildMlFeatureVector(sessionState, cartItems) {
  const totalDuration = Math.max(1.0, sessionState.elapsedSeconds || 1.0);
  const totalPages = Math.max(1, sessionState.totalPagesViewed || 1);

  // Calculate PageValues based on cart subtotal & item depth
  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const pageValues = cartSubtotal > 0 ? Number((cartSubtotal / totalPages).toFixed(2)) : 0.0;

  // Disengagement metrics
  const bounceRates = sessionState.totalPagesViewed <= 1 ? 0.20 : Number((0.02 / totalPages).toFixed(4));
  const exitRates = Number((sessionState.exitCount / totalPages).toFixed(4)) || 0.03;

  return {
    Administrative: sessionState.adminViews || 0,
    Administrative_Duration: Number((sessionState.adminDuration || 0.0).toFixed(2)),
    Informational: sessionState.infoViews || 0,
    Informational_Duration: Number((sessionState.infoDuration || 0.0).toFixed(2)),
    ProductRelated: sessionState.productViews || 0,
    ProductRelated_Duration: Number((sessionState.productDuration || 0.0).toFixed(2)),
    BounceRates: Math.min(1.0, Math.max(0.0, bounceRates)),
    ExitRates: Math.min(1.0, Math.max(0.0, exitRates)),
    PageValues: pageValues,
    SpecialDay: 0.0,
    Month: getCurrentMonthName(),
    OperatingSystems: 2,
    Browser: 2,
    Region: 1,
    TrafficType: sessionState.searchCount > 0 ? 2 : 1,
    VisitorType: sessionState.isNewVisitor ? "New_Visitor" : "Returning_Visitor",
    Weekend: isWeekendNow(),
  };
}
