import React, { useState } from "react";
import { Clock, Eye, ShoppingCart, Search, Activity, ChevronDown, ChevronUp } from "lucide-react";
import { useSession } from "../context/SessionContext";
import { useCart } from "../context/CartContext";

export default function SessionIndicator() {
  const { elapsedSeconds, totalPagesViewed, productViews, searchCount } = useSession();
  const { cartCount } = useCart();
  const [isMinimized, setIsMinimized] = useState(false);

  const formatTime = (totalSec) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className={`session-indicator-panel ${isMinimized ? "minimized" : ""}`}>
      <div className="session-indicator-header" onClick={() => setIsMinimized(!isMinimized)}>
        <div className="session-header-title">
          <Activity size={16} className="text-primary pulse" />
          <span>Session Analytics</span>
        </div>
        <button className="minimize-btn">
          {isMinimized ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {!isMinimized && (
        <div className="session-indicator-body">
          <div className="metric-row">
            <span className="metric-label">
              <Eye size={14} /> Pages Viewed:
            </span>
            <span className="metric-value">{totalPagesViewed}</span>
          </div>

          <div className="metric-row">
            <span className="metric-label">
              <Eye size={14} /> Products Viewed:
            </span>
            <span className="metric-value">{productViews}</span>
          </div>

          <div className="metric-row">
            <span className="metric-label">
              <Search size={14} /> Searches:
            </span>
            <span className="metric-value">{searchCount}</span>
          </div>

          <div className="metric-row">
            <span className="metric-label">
              <ShoppingCart size={14} /> Cart Items:
            </span>
            <span className="metric-value">{cartCount}</span>
          </div>

          <div className="metric-row">
            <span className="metric-label">
              <Clock size={14} /> Session Time:
            </span>
            <span className="metric-value font-mono">{formatTime(elapsedSeconds)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
