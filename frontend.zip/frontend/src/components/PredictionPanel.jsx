import React from "react";
import { TrendingUp, AlertCircle, CheckCircle, RefreshCw } from "lucide-react";
import { useSession } from "../context/SessionContext";
import { useCart } from "../context/CartContext";

export default function PredictionPanel() {
  const { predictionResult, isPredicting, predictionError, fetchPrediction } = useSession();
  const { cartItems } = useCart();

  const handleEvaluate = () => {
    fetchPrediction(cartItems);
  };

  return (
    <div className="prediction-panel-card">
      <div className="prediction-panel-header">
        <div className="flex items-center gap-2">
          <TrendingUp size={18} className="text-primary" />
          <h3 className="prediction-title">Real-Time Purchase Intention ML Engine</h3>
        </div>
        <button
          className="btn btn-sm btn-outline flex items-center gap-1"
          onClick={handleEvaluate}
          disabled={isPredicting}
        >
          <RefreshCw size={14} className={isPredicting ? "spin" : ""} />
          {isPredicting ? "Analyzing..." : "Predict Intent"}
        </button>
      </div>

      <div className="prediction-panel-body">
        {predictionError && (
          <div className="prediction-error-banner">
            <AlertCircle size={16} />
            <span>{predictionError} (FastAPI Backend at http://localhost:8000)</span>
          </div>
        )}

        {!predictionResult && !predictionError && (
          <div className="prediction-placeholder">
            <div className="pulsing-dot" />
            <p>Analyzing shopping behavior patterns...</p>
            <span className="placeholder-subtext">
              Click &quot;Predict Intent&quot; to query the Random Forest model on backend.
            </span>
          </div>
        )}

        {predictionResult && (
          <div className="prediction-result-display">
            <div className="result-main-row">
              <div className="prediction-badge-wrapper">
                {predictionResult.prediction === 1 ? (
                  <span className="prediction-badge conversion">
                    <CheckCircle size={18} /> {predictionResult.label}
                  </span>
                ) : (
                  <span className="prediction-badge non-conversion">
                    <AlertCircle size={18} /> {predictionResult.label}
                  </span>
                )}
              </div>

              <div className="probability-metric">
                <span className="prob-label">Conversion Probability</span>
                <span className="prob-value">
                  {predictionResult.conversion_probability_percent}%
                </span>
              </div>
            </div>

            {/* Probability Progress Bar */}
            <div className="probability-progress-bar">
              <div
                className={`progress-fill ${predictionResult.prediction === 1 ? "high" : "low"}`}
                style={{ width: `${Math.min(100, predictionResult.conversion_probability_percent)}%` }}
              />
            </div>

            {/* Recommendation Container */}
            {predictionResult.recommendation && (
              <div className={`recommendation-box ${predictionResult.recommendation.action}`}>
                <span className="recommendation-heading">Merchant Action Recommendation:</span>
                <p className="recommendation-msg">{predictionResult.recommendation.message}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
