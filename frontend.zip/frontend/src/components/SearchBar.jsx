import React from "react";
import { Search, X } from "lucide-react";

export default function SearchBar({ searchQuery, setSearchQuery, onSearchSubmit }) {
  const handleClear = () => {
    setSearchQuery("");
  };

  return (
    <div className="search-bar-wrapper">
      <div className="search-input-container">
        <Search size={20} className="search-icon" />
        <input
          type="text"
          className="search-input"
          placeholder="Search products by name or category..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && onSearchSubmit) {
              onSearchSubmit(searchQuery);
            }
          }}
        />
        {searchQuery && (
          <button className="search-clear-btn" onClick={handleClear}>
            <X size={16} />
          </button>
        )}
      </div>
    </div>
  );
}
